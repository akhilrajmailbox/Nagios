/* Stub file for routines from xodtemplate.c */

int xodtemplate_read_config_data(const char *main_config_file, int options) { return OK; }
