/* Stub for base/utils.c */
void get_next_valid_time(time_t pref_time, time_t *valid_time, timeperiod *tperiod) {}
int update_check_stats(int check_type, time_t check_time) {}
int check_time_against_period(time_t test_time, timeperiod *tperiod) {}
void free_memory(nagios_macros *mac) {}
